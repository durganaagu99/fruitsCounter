import {Component} from 'react'

import './index.css'

class FruitsCounter extends Component {
  state = {mangoes: 0, bananas: 0}

  mangoesCount = () => {
    this.setState(prevState => ({mangoes: prevState.mangoes + 1}))
  }

  bananasCount = () => {
    this.setState(prevState => ({bananas: prevState.bananas + 1}))
  }

  render() {
    const {mangoes, bananas} = this.state

    return (
      <div className="bg-container">
        <div className="mini-container">
          <div>
            <h1 className="heading">
              Bob ate <span className="span">{mangoes}</span>mangoes
              <span className="span">{bananas}</span> bananas
            </h1>
          </div>
          <div>
            <img
              className="image"
              src="https://assets.ccbp.in/frontend/react-js/mango-img.png"
              alt="mangoes"
            />
            <img
              className="image"
              src="https://assets.ccbp.in/frontend/react-js/banana-img.png"
              alt="bananas"
            />
          </div>
          <div className="button-container">
            <button
              type="button"
              className="button"
              onClick={this.mangoesCount}
            >
              Eat Mango
            </button>
            <button
              type="button"
              className="button"
              onClick={this.bananasCount}
            >
              Eat Banana
            </button>
          </div>
        </div>
      </div>
    )
  }
}
export default FruitsCounter
